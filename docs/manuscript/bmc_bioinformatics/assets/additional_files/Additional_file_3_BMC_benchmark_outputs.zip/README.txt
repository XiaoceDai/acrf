Additional file 3 — Complete BMC benchmark outputs
Machine-readable TSV tables for the prespecified acrf benchmark.
Unfavorable or null comparator results are retained.
