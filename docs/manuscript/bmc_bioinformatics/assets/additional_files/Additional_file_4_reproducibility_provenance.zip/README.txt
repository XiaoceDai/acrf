Additional file 4 — Reproducibility and provenance package
Frozen program/family definitions, external gene-set curation manifest,
figure source-data manifests, and environment/hash records.
Excludes raw external datasets and identifiable participant-level data.
