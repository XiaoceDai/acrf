#!/usr/bin/env Rscript
#
# Example:
# Rscript normal_chamber_analysis.R \
#   --count=GSE112339/GSE112339_HTSeq_hg19_Ensembl.txt.gz \
#   --metadata=GSE112339/metadata.xlsx \
#   --hallmark_gmt=path/to/hallmark.gmt \
#   --reactome_gmt=path/to/reactome.gmt \
#   --out_dir=.

suppressPackageStartupMessages({
  library(data.table)
  library(edgeR)
  library(limma)
  library(fgsea)
})

parse_args <- function(args) {
  out <- list()
  for (a in args) {
    if (!startsWith(a, "--")) next
    kv <- strsplit(sub("^--", "", a), "=", fixed = TRUE)[[1]]
    key <- kv[1]
    val <- if (length(kv) >= 2) paste(kv[-1], collapse = "=") else "TRUE"
    out[[key]] <- val
  }
  out
}

get_arg <- function(args, key, default = NULL) {
  if (!is.null(args[[key]])) args[[key]] else default
}

require_existing_arg <- function(path, flag, label) {
  if (is.na(path) || !nzchar(path)) {
    stop(
      label, " is required. Please pass ", flag, "=<path>.",
      call. = FALSE
    )
  }
  if (!file.exists(path)) {
    stop(
      label, " not found: ", path,
      "\nPlease verify ", flag, "=<path>.",
      call. = FALSE
    )
  }
}

normalize_chamber <- function(x) {
  x <- toupper(trimws(as.character(x)))
  ans <- rep(NA_character_, length(x))
  ans[x %chin% c("LA", "LEFT ATRIUM", "LEFT_ATRIUM", "LEFT-ATRIUM")] <- "LA"
  ans[x %chin% c("RA", "RIGHT ATRIUM", "RIGHT_ATRIUM", "RIGHT-ATRIUM")] <- "RA"
  ans
}

parse_gse112339_count_sample_id <- function(title) {
  title <- trimws(as.character(title))
  title <- sub("\\s*\\[.*$", "", title)
  parts <- strsplit(title, "_", fixed = TRUE)[[1]]
  if (length(parts) != 2) return(NA_character_)

  donor_part <- gsub("-", "_", parts[1], fixed = TRUE)
  chamber_part <- toupper(parts[2])
  if (chamber_part == "SEPTUM") chamber_part <- "IVS"
  paste(chamber_part, donor_part, sep = "_")
}

extract_geo_heart_id <- function(x) {
  x <- as.character(x)
  out <- sub(".*heart id:\\s*", "", x, ignore.case = TRUE)
  out[!grepl("heart id\\s*:", x, ignore.case = TRUE)] <- NA_character_
  out
}

load_gse112339_geo_map <- function() {
  if (!requireNamespace("GEOquery", quietly = TRUE)) {
    stop(
      "GEOquery is required to map GSM accessions to GSE112339 count-matrix sample IDs.",
      call. = FALSE
    )
  }

  message("Mapping metadata GSM accessions through GEO GSE112339 annotation")
  gse <- GEOquery::getGEO("GSE112339", GSEMatrix = TRUE, getGPL = FALSE)
  if (length(gse) < 1) stop("Failed to load GEO annotation for GSE112339.", call. = FALSE)

  pd <- as.data.table(Biobase::pData(gse[[1]]))
  if (!all(c("geo_accession", "title", "characteristics_ch1.2") %in% names(pd))) {
    stop("GEO annotation is missing expected columns for GSE112339.", call. = FALSE)
  }

  geo_map <- pd[, .(
    sample_id = as.character(geo_accession),
    count_sample_id = vapply(title, parse_gse112339_count_sample_id, character(1)),
    donor = extract_geo_heart_id(`characteristics_ch1.2`),
    chamber = normalize_chamber(sub(".*_", "", sub("\\s*\\[.*$", "", title)))
  )]
  geo_map <- geo_map[
    !is.na(sample_id) & nzchar(sample_id) &
      !is.na(count_sample_id) & nzchar(count_sample_id)
  ]
  unique(geo_map)
}

read_external_metadata <- function(metadata_path) {
  ext <- tolower(tools::file_ext(metadata_path))
  ext_meta <- switch(
    ext,
    "tsv" = fread(metadata_path),
    "txt" = fread(metadata_path),
    "csv" = fread(metadata_path),
    "xlsx" = {
      if (!requireNamespace("readxl", quietly = TRUE)) {
        stop("metadata is .xlsx but readxl is unavailable.", call. = FALSE)
      }
      as.data.table(readxl::read_xlsx(metadata_path))
    },
    stop("Unsupported metadata extension: ", ext)
  )

  clean_names <- tolower(gsub("[^a-zA-Z0-9]+", "_", names(ext_meta)))
  setnames(ext_meta, names(ext_meta), clean_names)

  sample_col <- if ("sample_id" %in% names(ext_meta)) "sample_id" else if ("geo_accession" %in% names(ext_meta)) "geo_accession" else NA_character_
  donor_col <- if ("donor_id" %in% names(ext_meta)) "donor_id" else if ("donor" %in% names(ext_meta)) "donor" else NA_character_
  chamber_col <- if ("chamber" %in% names(ext_meta)) "chamber" else NA_character_

  if (is.na(sample_col) || is.na(donor_col) || is.na(chamber_col)) {
    stop("Metadata must contain sample_id (or geo_accession), donor_id (or donor), and chamber.", call. = FALSE)
  }

  ext_meta[, .(
    sample_id = as.character(get(sample_col)),
    donor = as.character(get(donor_col)),
    chamber = normalize_chamber(get(chamber_col))
  )]
}

harmonize_metadata_sample_ids <- function(ext_keep, sample_ids) {
  overlap_n <- sum(ext_keep$sample_id %chin% sample_ids)
  has_gsm_ids <- any(grepl("^GSM\\d+$", ext_keep$sample_id, ignore.case = TRUE))
  if (!has_gsm_ids || overlap_n == nrow(ext_keep)) {
    return(ext_keep)
  }

  geo_map <- load_gse112339_geo_map()
  ext_keep <- merge(ext_keep, geo_map, by = "sample_id", all.x = TRUE, sort = FALSE, suffixes = c("_meta", "_geo"))
  ext_keep[, sample_id := fifelse(!is.na(count_sample_id) & count_sample_id %chin% sample_ids, count_sample_id, sample_id)]
  ext_keep[is.na(donor_meta) | !nzchar(donor_meta), donor_meta := donor_geo]
  ext_keep[is.na(chamber_meta) | !nzchar(chamber_meta), chamber_meta := chamber_geo]
  unique(ext_keep[, .(sample_id, donor = donor_meta, chamber = chamber_meta)])
}

read_metadata <- function(metadata_path, sample_ids) {
  meta <- data.table(sample_id = sample_ids)
  meta[, chamber := sub("_.*$", "", sample_id)]
  meta[, donor := sub("^[^_]+_", "", sample_id)]

  if (is.na(metadata_path) || !nzchar(metadata_path) || !file.exists(metadata_path)) {
    return(meta)
  }

  ext_keep <- read_external_metadata(metadata_path)
  ext_keep <- ext_keep[!is.na(sample_id) & nzchar(sample_id)]
  ext_keep <- ext_keep[!duplicated(sample_id)]
  ext_keep <- harmonize_metadata_sample_ids(ext_keep, sample_ids)
  ext_keep <- ext_keep[!duplicated(sample_id)]

  meta <- merge(meta, ext_keep, by = "sample_id", all.x = TRUE, suffixes = c("_infer", "_meta"))
  meta[, donor := fifelse(!is.na(donor_meta) & nzchar(donor_meta), donor_meta, donor_infer)]
  meta[, chamber := fifelse(!is.na(chamber_meta) & nzchar(chamber_meta), chamber_meta, chamber_infer)]
  meta <- meta[, .(sample_id, donor, chamber)]
  meta
}

fit_chamber <- function(dge, meta) {
  design <- model.matrix(~ donor + chamber, data = meta)
  coef_name <- grep("^chamber", colnames(design), value = TRUE)
  if (length(coef_name) != 1) {
    stop("Expected one chamber coefficient, got: ", paste(coef_name, collapse = ", "))
  }
  v <- voom(dge, design, plot = FALSE)
  fit <- eBayes(lmFit(v, design))
  tt <- as.data.table(topTable(fit, coef = coef_name, number = Inf, sort.by = "none"), keep.rownames = "gene_key")
  list(v = v, fit = fit, tt = tt, coef_name = coef_name)
}

make_rank_stats <- function(gene_table) {
  rank_dt <- gene_table[, .(
    rank_id = fifelse(!is.na(gene_symbol) & nzchar(gene_symbol), gene_symbol, ensembl_id),
    stat = moderated_t
  )]
  rank_dt <- rank_dt[!is.na(rank_id) & nzchar(rank_id) & is.finite(stat)]
  rank_dt <- rank_dt[order(-abs(stat))]
  rank_dt <- rank_dt[!duplicated(rank_id)]
  stats <- rank_dt$stat
  names(stats) <- rank_dt$rank_id
  sort(stats, decreasing = TRUE)
}

load_pathways <- function(hallmark_gmt, reactome_gmt) {
  if (!file.exists(hallmark_gmt)) stop("Hallmark GMT not found: ", hallmark_gmt)
  if (!file.exists(reactome_gmt)) stop("Reactome GMT not found: ", reactome_gmt)

  h <- fgsea::gmtPathways(hallmark_gmt)
  r <- fgsea::gmtPathways(reactome_gmt)
  names(h) <- paste0("HALLMARK__", names(h))
  names(r) <- paste0("REACTOME__", names(r))
  c(h, r)
}

safe_row_zscore <- function(mat) {
  if (nrow(mat) == 0 || ncol(mat) == 0) return(mat)
  z <- t(scale(t(mat)))
  z[is.na(z)] <- 0
  z
}

cell_nature_cols <- list(
  la = "#4DBBD5FF",
  ra = "#E64B35FF",
  ns = "#BEBEBE",
  pair = "#7F7F7F80",
  line = "#7F7F7F",
  heat_low = "#3C5488FF",
  heat_mid = "#F7F7F7",
  heat_high = "#E64B35FF"
)

open_pdf_device <- function(out_file, width, height) {
  pdf(out_file, width = width, height = height, useDingbats = FALSE)
}

draw_pair_segments <- function(dt, x_col, y_col) {
  donors <- unique(dt$donor)
  for (d in donors) {
    pair_dt <- dt[donor == d]
    if (nrow(pair_dt) != 2) next
    segments(
      x0 = pair_dt[[x_col]][1], y0 = pair_dt[[y_col]][1],
      x1 = pair_dt[[x_col]][2], y1 = pair_dt[[y_col]][2],
      col = cell_nature_cols$pair, lwd = 1.1
    )
  }
}

plot_paired_scatter <- function(dt, x_col, y_col, xlab, ylab, main, out_file, width = 9.5, height = 8.0) {
  open_pdf_device(out_file, width = width, height = height)
  cols <- ifelse(dt$chamber == "LA", cell_nature_cols$la, cell_nature_cols$ra)
  plot(
    dt[[x_col]], dt[[y_col]],
    pch = 19, col = cols,
    xlab = xlab, ylab = ylab,
    main = main
  )
  draw_pair_segments(dt, x_col, y_col)
  text(dt[[x_col]], dt[[y_col]], labels = dt$sample_id, pos = 3, cex = 0.75)
  legend(
    "topright",
    legend = c("LA", "RA"),
    col = c(cell_nature_cols$la, cell_nature_cols$ra),
    pch = 19, bty = "n"
  )
  dev.off()
}

plot_figure1a <- function(pca_dt, out_file) {
  plot_paired_scatter(
    dt = pca_dt,
    x_col = "PC1",
    y_col = "PC2",
    xlab = "PC1",
    ylab = "PC2",
    main = "Figure 1A: GSE112339 PCA (LA vs RA)",
    out_file = out_file,
    width = 9.5,
    height = 8.0
  )
}

plot_correlation_heatmap <- function(corr_mat, out_file) {
  open_pdf_device(out_file, width = 9.5, height = 8.5)
  ord <- hclust(as.dist(1 - corr_mat))$order
  pal <- colorRampPalette(c("white", cell_nature_cols$heat_low, cell_nature_cols$heat_high))(100)
  heatmap(
    corr_mat[ord, ord],
    Rowv = NA,
    Colv = NA,
    scale = "none",
    margins = c(8, 8),
    col = pal
  )
  dev.off()
}

write_pca_chamber_lm <- function(pca_dt, out_file_txt, out_file_tsv) {
  df_pca <- as.data.frame(pca_dt)
  df_pca$chamber <- factor(df_pca$chamber, levels = c("RA", "LA"))
  df_pca$donor <- factor(df_pca$donor)

  fit_pc1 <- lm(PC1 ~ chamber + donor, data = df_pca)
  fit_pc2 <- lm(PC2 ~ chamber + donor, data = df_pca)

  txt <- c(
    "summary(lm(PC1 ~ chamber + donor, data = df_pca))",
    capture.output(summary(fit_pc1)),
    "",
    "summary(lm(PC2 ~ chamber + donor, data = df_pca))",
    capture.output(summary(fit_pc2))
  )
  writeLines(txt, con = out_file_txt)

  tidy_one <- function(fit, response_name) {
    cf <- as.data.table(summary(fit)$coefficients, keep.rownames = "term")
    setnames(cf, c("term", "estimate", "std_error", "t_value", "p_value"))
    cf[, response := response_name]
    cf
  }

  lm_dt <- rbindlist(list(
    tidy_one(fit_pc1, "PC1"),
    tidy_one(fit_pc2, "PC2")
  ), fill = TRUE)
  lm_dt <- lm_dt[, .(response, term, estimate, std_error, t_value, p_value)]
  fwrite(lm_dt, out_file_tsv, sep = "\t")
}

plot_logcpm_mean_variance <- function(log_cpm_mat, out_file) {
  gene_mean <- rowMeans(log_cpm_mat)
  gene_var <- apply(log_cpm_mat, 1, var)
  ord <- order(gene_mean)
  smooth_xy <- lowess(gene_mean[ord], gene_var[ord], f = 0.2)

  open_pdf_device(out_file, width = 9.5, height = 8.0)
  plot(
    gene_mean, gene_var,
    pch = 16, cex = 0.35,
    col = adjustcolor(cell_nature_cols$line, alpha.f = 0.28),
    xlab = "rowMeans(logCPM)",
    ylab = "apply(logCPM, 1, var)",
    main = "Gene Mean-Variance Diagnostic"
  )
  lines(smooth_xy$x, smooth_xy$y, col = cell_nature_cols$ra, lwd = 2.2)
  dev.off()
}

clean_program_name <- function(x) {
  x <- sub("^HALLMARK__", "", x)
  x <- sub("^REACTOME__", "", x)
  x <- sub("^HALLMARK_", "", x)
  x <- sub("^REACTOME_", "", x)
  x <- gsub("_", " ", x)
  tools::toTitleCase(tolower(x))
}

classify_program <- function(program_name) {
  x <- tolower(program_name)
  if (grepl("oxidative phosphorylation|respiratory electron transport|aerobic respiration|mitochondrial", x)) return("mitochondrial metabolism")
  if (grepl("translation", x)) return("translation")
  if (grepl("heparan sulfate|gag|glycosaminoglycan|ecm|matrix|collagen", x)) return("ECM/GAG remodeling")
  if (grepl("bmp|runx|development|signaling", x)) return("developmental signaling")
  "other"
}

top_feature_genes <- function(x, n = 8L) {
  genes <- unlist(strsplit(as.character(x), ",", fixed = TRUE))
  genes <- genes[nzchar(genes)]
  paste(head(genes, n), collapse = ",")
}

plot_figure1b <- function(gene_out, expr_mat, meta, out_file, gene_fdr_cutoff = 0.05, top_each = 20, anchor_logfc = 0.5) {
  # Volcano panel data
  volc <- copy(gene_out)
  volc[, neglog10fdr := -log10(pmax(fdr, 1e-300))]
  volc[, sig_class := fifelse(fdr < gene_fdr_cutoff & logFC > 0, "LA-high",
    fifelse(fdr < gene_fdr_cutoff & logFC < 0, "RA-high", "NS")
  )]

  # Heatmap panel data: top chamber genes from both sides
  la_top <- volc[fdr < gene_fdr_cutoff & logFC > anchor_logfc][order(-moderated_t)]
  ra_top <- volc[fdr < gene_fdr_cutoff & logFC < -anchor_logfc][order(moderated_t)]
  if (nrow(la_top) < top_each) la_top <- volc[logFC > 0][order(-moderated_t)]
  if (nrow(ra_top) < top_each) ra_top <- volc[logFC < 0][order(moderated_t)]
  la_top <- head(la_top, top_each)
  ra_top <- head(ra_top, top_each)
  sel_keys <- unique(c(la_top$gene_key, ra_top$gene_key))

  hm <- matrix(numeric(0), nrow = 0, ncol = 0)
  row_labels <- character(0)
  meta_ord <- copy(meta)
  if (length(sel_keys) > 0) {
    col_ord <- order(meta$chamber, meta$donor)
    meta_ord <- meta[col_ord]
    hm <- expr_mat[sel_keys, meta_ord$sample_id, drop = FALSE]
    hm <- safe_row_zscore(hm)
    row_dt <- volc[match(rownames(hm), gene_key)]
    row_labels <- fifelse(!is.na(row_dt$gene_symbol) & nzchar(row_dt$gene_symbol), row_dt$gene_symbol, row_dt$ensembl_id)
    row_labels <- make.unique(as.character(row_labels))
    row_ord <- order(row_dt$logFC, decreasing = TRUE)
    hm <- hm[row_ord, , drop = FALSE]
    row_labels <- row_labels[row_ord]
  }

  open_pdf_device(out_file, width = 16, height = 8)
  layout(matrix(c(1, 2), nrow = 1), widths = c(1.0, 1.25))

  par(mar = c(5, 5, 3, 1))
  pt_col <- ifelse(volc$sig_class == "LA-high", cell_nature_cols$la,
    ifelse(volc$sig_class == "RA-high", cell_nature_cols$ra, cell_nature_cols$ns)
  )
  plot(
    volc$logFC, volc$neglog10fdr,
    pch = 16, cex = 0.55, col = pt_col,
    xlab = "logFC (LA relative to RA)",
    ylab = "-log10(FDR)",
    main = "Figure 1B (left): Volcano"
  )
  abline(v = c(-0.5, 0.5), col = "#636363", lty = 2)
  abline(h = -log10(gene_fdr_cutoff), col = "#636363", lty = 2)
  top_label <- volc[fdr < gene_fdr_cutoff][order(-abs(moderated_t))]
  top_label <- head(top_label, 12)
  if (nrow(top_label) > 0) {
    lbl <- fifelse(!is.na(top_label$gene_symbol) & nzchar(top_label$gene_symbol), top_label$gene_symbol, top_label$ensembl_id)
    text(top_label$logFC, top_label$neglog10fdr, labels = lbl, pos = 3, cex = 0.65)
  }
  legend(
    "topright",
    legend = c("LA-high (FDR<0.05)", "RA-high (FDR<0.05)", "NS"),
    col = c(cell_nature_cols$la, cell_nature_cols$ra, cell_nature_cols$ns),
    pch = 16, bty = "n", cex = 0.85
  )

  par(mar = c(10, 9, 3, 2))
  if (nrow(hm) == 0 || ncol(hm) == 0) {
    plot.new()
    title(main = "Figure 1B (right): Top chamber genes heatmap")
    text(0.5, 0.5, "No genes passed the current selection rule")
  } else {
    nc <- ncol(hm)
    nr <- nrow(hm)
    pal <- colorRampPalette(c(cell_nature_cols$heat_low, cell_nature_cols$heat_mid, cell_nature_cols$heat_high))(100)
    lim <- max(abs(hm))
    image(
      x = seq_len(nc), y = seq_len(nr),
      z = t(hm[nr:1, , drop = FALSE]),
      col = pal, zlim = c(-lim, lim),
      axes = FALSE,
      xlab = "", ylab = "",
      main = "Figure 1B (right): Top chamber genes heatmap"
    )
    cex_x <- if (nc > 20) 0.45 else 0.7
    cex_y <- if (nr > 35) 0.4 else 0.6
    axis(1, at = seq_len(nc), labels = meta_ord$sample_id, las = 2, cex.axis = cex_x)
    axis(2, at = seq_len(nr), labels = rev(row_labels), las = 2, cex.axis = cex_y)
    box()
    n_ra <- sum(meta_ord$chamber == "RA")
    if (n_ra > 0 && n_ra < nc) {
      abline(v = n_ra + 0.5, lwd = 2, col = "black")
      mtext("RA | LA", side = 3, line = 0.2, cex = 0.8)
    }
  }
  dev.off()
}

main <- function() {
  args <- parse_args(commandArgs(trailingOnly = TRUE))

  count_path <- get_arg(args, "count", "GSE112339/GSE112339_HTSeq_hg19_Ensembl.txt.gz")
  metadata_path <- get_arg(args, "metadata", "GSE112339/metadata.xlsx")
  hallmark_gmt <- get_arg(args, "hallmark_gmt", "")
  reactome_gmt <- get_arg(args, "reactome_gmt", "")
  out_dir <- get_arg(args, "out_dir", ".")
  top_programs <- as.integer(get_arg(args, "top_programs", "5"))
  gene_fdr_cutoff <- as.numeric(get_arg(args, "gene_fdr", "0.05"))
  path_fdr_cutoff <- as.numeric(get_arg(args, "pathway_fdr", "0.05"))
  top_heatmap_genes_per_side <- as.integer(get_arg(args, "top_heatmap_genes_per_side", "20"))

  require_existing_arg(count_path, "--count", "Count matrix")
  require_existing_arg(metadata_path, "--metadata", "Metadata file")
  require_existing_arg(hallmark_gmt, "--hallmark_gmt", "Hallmark GMT")
  require_existing_arg(reactome_gmt, "--reactome_gmt", "Reactome GMT")

  if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE)
  qc_dir <- file.path(out_dir, "qc")
  if (!dir.exists(qc_dir)) dir.create(qc_dir, recursive = TRUE)
  fig_dir <- file.path(out_dir, "figures")
  if (!dir.exists(fig_dir)) dir.create(fig_dir, recursive = TRUE)

  message("[1/8] Reading count matrix")
  counts_dt <- fread(count_path)
  gene_id_col <- names(counts_dt)[1]
  sample_ids <- names(counts_dt)[-1]

  message("[2/8] Building metadata and enforcing paired LA/RA")
  meta <- read_metadata(metadata_path, sample_ids)
  meta <- meta[chamber %chin% c("LA", "RA")]
  meta <- meta[sample_id %chin% sample_ids]
  setorder(meta, donor, chamber)

  pair_tab <- dcast(meta, donor ~ chamber, value.var = "sample_id", fun.aggregate = length, fill = 0)
  valid_donor <- pair_tab[LA == 1 & RA == 1, donor]
  meta <- meta[donor %chin% valid_donor]

  if (length(unique(meta$donor)) != 8) {
    stop("Metadata curation failed: need exactly 8 paired donors; got ", length(unique(meta$donor)))
  }
  if (nrow(meta) != 16) {
    stop("Metadata curation failed: need exactly 16 LA/RA samples; got ", nrow(meta))
  }

  meta[, donor := factor(donor)]
  meta[, chamber := factor(chamber, levels = c("RA", "LA"))]

  sample_use <- meta$sample_id
  miss <- setdiff(sample_use, names(counts_dt))
  if (length(miss) > 0) stop("Samples missing in count matrix: ", paste(miss, collapse = ", "))

  raw_gene_id <- as.character(counts_dt[[gene_id_col]])
  gene_key <- make.unique(raw_gene_id, sep = "_dup")
  gene_map <- data.table(
    gene_key = gene_key,
    gene_id_raw = raw_gene_id,
    ensembl_id = ifelse(grepl("^ENSG", raw_gene_id, ignore.case = TRUE), sub("\\..*$", "", raw_gene_id), raw_gene_id),
    gene_symbol = ifelse(grepl("^ENSG", raw_gene_id, ignore.case = TRUE), NA_character_, raw_gene_id)
  )

  counts_mat <- as.matrix(counts_dt[, ..sample_use])
  rownames(counts_mat) <- gene_key
  storage.mode(counts_mat) <- "integer"

  dge <- DGEList(counts = counts_mat)

  message("[3/8] Minimal QC")
  qc_lib <- data.table(
    sample_id = sample_use,
    donor = as.character(meta$donor),
    chamber = as.character(meta$chamber),
    library_size = colSums(dge$counts),
    detected_genes = colSums(dge$counts > 0)
  )
  fwrite(qc_lib, file.path(qc_dir, "qc_library_and_detected_genes.tsv"), sep = "\t")

  log_cpm_all <- cpm(dge, log = TRUE, prior.count = 1)
  corr <- cor(log_cpm_all, method = "spearman")
  corr_dt <- as.data.table(as.table(corr))
  setnames(corr_dt, c("sample_1", "sample_2", "spearman_corr"))
  fwrite(corr_dt, file.path(qc_dir, "qc_sample_correlation.tsv"), sep = "\t")

  plot_correlation_heatmap(corr, file.path(qc_dir, "qc_sample_correlation_heatmap.pdf"))

  pca <- prcomp(t(log_cpm_all), scale. = TRUE)
  pca_dt <- data.table(
    sample_id = rownames(pca$x),
    PC1 = pca$x[, 1],
    PC2 = pca$x[, 2]
  )
  pca_dt <- merge(pca_dt, meta[, .(sample_id, donor, chamber)], by = "sample_id", all.x = TRUE)
  fwrite(pca_dt, file.path(qc_dir, "qc_pca.tsv"), sep = "\t")
  write_pca_chamber_lm(
    pca_dt = pca_dt,
    out_file_txt = file.path(qc_dir, "qc_pca_chamber_lm.txt"),
    out_file_tsv = file.path(qc_dir, "qc_pca_chamber_lm_coefficients.tsv")
  )
  plot_figure1a(pca_dt, file.path(fig_dir, "figure1A_gse112339_pca_la_vs_ra.pdf"))
  plot_paired_scatter(
    dt = pca_dt,
    x_col = "PC1",
    y_col = "PC2",
    xlab = "PC1",
    ylab = "PC2",
    main = "PCA (logCPM)",
    out_file = file.path(qc_dir, "qc_pca.pdf"),
    width = 9.5,
    height = 8.0
  )
  plot_logcpm_mean_variance(
    log_cpm_mat = log_cpm_all,
    out_file = file.path(qc_dir, "qc_logcpm_mean_variance.pdf")
  )

  mds <- plotMDS(log_cpm_all, plot = FALSE)
  mds_dt <- data.table(sample_id = colnames(log_cpm_all), MDS1 = mds$x, MDS2 = mds$y)
  mds_dt <- merge(mds_dt, meta[, .(sample_id, donor, chamber)], by = "sample_id", all.x = TRUE)
  fwrite(mds_dt, file.path(qc_dir, "qc_mds.tsv"), sep = "\t")
  plot_paired_scatter(
    dt = mds_dt,
    x_col = "MDS1",
    y_col = "MDS2",
    xlab = "MDS1",
    ylab = "MDS2",
    main = "MDS",
    out_file = file.path(qc_dir, "qc_mds.pdf"),
    width = 9.5,
    height = 8.0
  )

  message("[4/8] Low-expression filtering and normalization")
  keep <- rowSums(cpm(dge) > 1) >= 4
  dge <- dge[keep, , keep.lib.sizes = FALSE]
  dge <- calcNormFactors(dge, method = "TMM")
  gene_map <- gene_map[gene_key %chin% rownames(dge)]

  message("[5/8] Paired chamber model and full differential ranking")
  fit_full <- fit_chamber(dge, meta)
  gene_out <- merge(fit_full$tt, gene_map, by = "gene_key", all.x = TRUE, sort = FALSE)
  gene_out[, `:=`(
    logFC = logFC,
    moderated_t = t,
    p_value = P.Value,
    fdr = adj.P.Val,
    average_expression = AveExpr,
    direction = ifelse(logFC >= 0, "LA-high", "RA-high")
  )]
  gene_out[, fgsea_id := fifelse(!is.na(gene_symbol) & nzchar(gene_symbol), gene_symbol, ensembl_id)]

  message("[6/8] Leave-one-donor-out stability (genes + programs)")
  donors <- levels(meta$donor)
  lodo_gene <- data.table(gene_key = gene_out$gene_key)
  lodo_prog_list <- vector("list", length(donors))
  names(lodo_prog_list) <- donors

  pathways <- load_pathways(hallmark_gmt, reactome_gmt)
  rank_full <- make_rank_stats(gene_out)
  fgsea_full <- as.data.table(fgsea(pathways = pathways, stats = rank_full, minSize = 15, maxSize = 500))
  fgsea_full[, direction := ifelse(NES >= 0, "LA-biased", "RA-biased")]
  fgsea_full[, leading_edge_genes := vapply(leadingEdge, function(x) paste(x, collapse = ","), character(1))]
  fgsea_full[, leading_edge_n := lengths(leadingEdge)]

  for (d in donors) {
    idx <- meta$donor != d
    meta_i <- droplevels(meta[idx])
    dge_i <- dge[, idx, keep.lib.sizes = FALSE]
    dge_i <- calcNormFactors(dge_i, method = "TMM")
    fit_i <- fit_chamber(dge_i, meta_i)

    t_i <- fit_i$tt[, .(gene_key, t)]
    setnames(t_i, "t", paste0("t_drop_", d))
    lodo_gene <- merge(lodo_gene, t_i, by = "gene_key", all.x = TRUE, sort = FALSE)

    gene_i <- merge(fit_i$tt, gene_map, by = "gene_key", all.x = TRUE, sort = FALSE)
    gene_i[, moderated_t := t]
    rank_i <- make_rank_stats(gene_i)
    fg_i <- as.data.table(fgsea(pathways = pathways, stats = rank_i, minSize = 15, maxSize = 500))
    lodo_prog_list[[d]] <- fg_i[, .(pathway, NES)]
  }

  drop_gene_cols <- grep("^t_drop_", names(lodo_gene), value = TRUE)
  gene_stab <- merge(
    gene_out[, .(gene_key, moderated_t)],
    lodo_gene,
    by = "gene_key",
    all.x = TRUE,
    sort = FALSE
  )
  gene_drop_mat <- as.matrix(gene_stab[, ..drop_gene_cols])
  full_sign <- sign(gene_stab$moderated_t)
  same_sign <- sweep(sign(gene_drop_mat), 1, full_sign, `==`)
  non_zero <- sign(gene_drop_mat) != 0
  gene_out[, stability_consistent_runs := rowSums(same_sign & non_zero, na.rm = TRUE)]
  gene_out[, stable_gene := stability_consistent_runs >= 7]

  prog_stab <- fgsea_full[, .(pathway, NES)]
  for (d in donors) {
    tmp <- copy(lodo_prog_list[[d]])
    setnames(tmp, "NES", paste0("NES_drop_", d))
    prog_stab <- merge(prog_stab, tmp, by = "pathway", all.x = TRUE, sort = FALSE)
  }

  drop_prog_cols <- grep("^NES_drop_", names(prog_stab), value = TRUE)
  prog_drop_mat <- as.matrix(prog_stab[, ..drop_prog_cols])
  prog_sign <- sign(prog_stab$NES)
  prog_same <- sweep(sign(prog_drop_mat), 1, prog_sign, `==`)
  prog_nonzero <- sign(prog_drop_mat) != 0
  prog_stab[, stability_consistent_runs := rowSums(prog_same & prog_nonzero, na.rm = TRUE)]
  prog_stab[, stable_program := stability_consistent_runs >= 6]

  fgsea_full <- merge(
    fgsea_full,
    prog_stab[, .(pathway, stability_consistent_runs, stable_program)],
    by = "pathway",
    all.x = TRUE,
    sort = FALSE
  )

  message("[7/8] Core programs and core genes")
  sig_genes <- unique(gene_out[fdr < gene_fdr_cutoff, fgsea_id])
  sig_prog <- fgsea_full[padj < path_fdr_cutoff]

  setorder(sig_prog, -NES)
  la_keep <- head(sig_prog[direction == "LA-biased"], top_programs)
  setorder(sig_prog, NES)
  ra_keep <- head(sig_prog[direction == "RA-biased"], top_programs)
  prog_out <- rbindlist(list(la_keep, ra_keep), fill = TRUE)
  if (nrow(prog_out) == 0) {
    prog_out <- sig_prog[0]
  }

  core_list <- lapply(prog_out$pathway, function(pw) {
    le <- fgsea_full[pathway == pw, leadingEdge][[1]]
    core <- intersect(le, sig_genes)
    data.table(
      pathway = pw,
      core_genes = paste(core, collapse = ","),
      core_gene_n = length(core)
    )
  })
  core_dt <- if (length(core_list) > 0) rbindlist(core_list) else data.table(pathway = character(), core_genes = character(), core_gene_n = integer())
  prog_out <- merge(prog_out, core_dt, by = "pathway", all.x = TRUE, sort = FALSE)
  prog_out[is.na(core_genes), core_genes := ""]
  prog_out[is.na(core_gene_n), core_gene_n := 0L]

  core_map <- if (nrow(prog_out) > 0) {
    rbindlist(lapply(seq_len(nrow(prog_out)), function(i) {
      pw <- prog_out$pathway[i]
      cgs <- unlist(strsplit(prog_out$core_genes[i], ",", fixed = TRUE))
      cgs <- cgs[nzchar(cgs)]
      if (length(cgs) == 0) return(data.table(fgsea_id = character(), pathway = character()))
      data.table(fgsea_id = cgs, pathway = pw)
    }), fill = TRUE)
  } else {
    data.table(fgsea_id = character(), pathway = character())
  }

  if (nrow(core_map) > 0) {
    core_gene_tag <- core_map[, .(core_programs = paste(unique(pathway), collapse = ";")), by = fgsea_id]
    gene_out <- merge(gene_out, core_gene_tag, by = "fgsea_id", all.x = TRUE, sort = FALSE)
  } else {
    gene_out[, core_programs := NA_character_]
  }
  gene_out[, is_core_gene := !is.na(core_programs) & nzchar(core_programs)]

  message("[8/8] Writing final outputs")
  setorder(gene_out, -moderated_t)
  gene_final <- gene_out[, .(
    ensembl_id,
    gene_symbol,
    logFC = as.numeric(logFC),
    moderated_t = as.numeric(moderated_t),
    p_value = as.numeric(p_value),
    FDR = as.numeric(fdr),
    average_expression = as.numeric(average_expression),
    direction,
    stability_consistent_runs = as.integer(stability_consistent_runs),
    stable_gene = as.logical(stable_gene),
    is_core_gene = as.logical(is_core_gene),
    core_programs
  )]

  gene_core_final <- gene_final[
    stable_gene == TRUE &
      FDR < gene_fdr_cutoff &
      abs(logFC) >= 0.5,
    .(
      gene = fifelse(!is.na(gene_symbol) & nzchar(gene_symbol), gene_symbol, ensembl_id),
      gene_id = ensembl_id,
      logFC,
      FDR,
      direction,
      stability = as.integer(stability_consistent_runs),
      core_programs
    )
  ]
  gene_core_final[, abs_logFC := abs(logFC)]
  setorder(gene_core_final, direction, -abs_logFC, FDR)
  gene_core_final[, abs_logFC := NULL]

  gene_core_strict_final <- gene_final[
    stable_gene == TRUE &
      FDR < gene_fdr_cutoff &
      abs(logFC) >= 0.5 &
      is_core_gene == TRUE,
    .(
      gene = fifelse(!is.na(gene_symbol) & nzchar(gene_symbol), gene_symbol, ensembl_id),
      gene_id = ensembl_id,
      logFC,
      FDR,
      direction,
      stability = as.integer(stability_consistent_runs),
      core_programs
    )
  ]
  gene_core_strict_final[, abs_logFC := abs(logFC)]
  setorder(gene_core_strict_final, direction, -abs_logFC, FDR)
  gene_core_strict_final[, abs_logFC := NULL]

  prog_final <- prog_out[, .(
    program_id = pathway,
    program = vapply(pathway, clean_program_name, character(1)),
    program_class = vapply(vapply(pathway, clean_program_name, character(1)), classify_program, character(1)),
    direction,
    NES = as.numeric(NES),
    FDR = as.numeric(padj),
    top_core_genes = vapply(core_genes, top_feature_genes, character(1)),
    leading_edge_genes = leading_edge_genes,
    core_genes,
    leading_edge_n = as.integer(leading_edge_n),
    core_gene_n = as.integer(core_gene_n),
    stability_consistent_runs = as.integer(stability_consistent_runs),
    stable_program = as.logical(stable_program)
  )]

  bulk_de_full <- gene_final[, .(
    gene_id = ensembl_id,
    gene_symbol,
    logFC,
    FDR,
    t_stat = moderated_t
  )]

  bulk_stability <- gene_final[, .(
    gene_id = ensembl_id,
    gene_symbol,
    direction,
    stability_score = as.integer(stability_consistent_runs)
  )]

  bulk_core_genes <- gene_final[
    stable_gene == TRUE &
      FDR < gene_fdr_cutoff &
      abs(logFC) > 0.5 &
      stability_consistent_runs >= 7,
    .(
      gene_id = ensembl_id,
      gene_symbol,
      direction,
      logFC,
      FDR,
      stability_score = as.integer(stability_consistent_runs)
    )
  ]
  bulk_core_genes[, abs_logFC := abs(logFC)]
  setorder(bulk_core_genes, direction, -abs_logFC, FDR)
  bulk_core_genes[, abs_logFC := NULL]

  bulk_fgsea <- prog_final[, .(
    pathway = program,
    direction,
    NES,
    FDR,
    leading_edge_genes,
    top_core_genes,
    program_class,
    stability_score = as.integer(stability_consistent_runs),
    stable_program
  )]

  prior_gene <- gene_core_final[, .(
    feature = gene,
    type = "gene",
    direction,
    evidence = "stable"
  )]

  prior_pathway <- prog_final[, .(
    feature = program,
    type = "pathway",
    direction = fifelse(direction == "LA-biased", "LA-high", "RA-high"),
    evidence = fifelse(FDR < 0.001 & stable_program == TRUE, "strong",
      fifelse(stable_program == TRUE, "moderate", "weak")
    )
  )]

  normal_chamber_prior <- unique(rbindlist(list(prior_gene, prior_pathway), fill = TRUE))

  plot_figure1b(
    gene_out = gene_out,
    expr_mat = fit_full$v$E,
    meta = meta,
    out_file = file.path(fig_dir, "figure1B_gse112339_volcano_heatmap.pdf"),
    gene_fdr_cutoff = gene_fdr_cutoff,
    top_each = top_heatmap_genes_per_side,
    anchor_logfc = 0.5
  )

  fwrite(gene_final, file.path(out_dir, "normal_chamber_genes.tsv"), sep = "\t", na = "NA")
  fwrite(gene_final, file.path(out_dir, "normal_chamber_genes_full.tsv"), sep = "\t", na = "NA")
  fwrite(gene_core_final, file.path(out_dir, "normal_chamber_genes_core.tsv"), sep = "\t", na = "NA")
  fwrite(gene_core_strict_final, file.path(out_dir, "normal_chamber_genes_core_strict.tsv"), sep = "\t", na = "NA")
  fwrite(prog_final, file.path(out_dir, "normal_chamber_programs.tsv"), sep = "\t", na = "NA")
  fwrite(bulk_de_full, file.path(out_dir, "bulk_chamber_DE_full.tsv"), sep = "\t", na = "NA")
  fwrite(bulk_stability, file.path(out_dir, "bulk_chamber_stability.tsv"), sep = "\t", na = "NA")
  fwrite(bulk_core_genes, file.path(out_dir, "bulk_chamber_core_genes.tsv"), sep = "\t", na = "NA")
  fwrite(bulk_fgsea, file.path(out_dir, "bulk_chamber_fgsea.tsv"), sep = "\t", na = "NA")
  fwrite(normal_chamber_prior, file.path(out_dir, "NormalChamberPrior.tsv"), sep = "\t", na = "NA")

  message("Done. Outputs:")
  message(" - ", file.path(out_dir, "normal_chamber_genes.tsv"))
  message(" - ", file.path(out_dir, "normal_chamber_genes_full.tsv"))
  message(" - ", file.path(out_dir, "normal_chamber_genes_core.tsv"))
  message(" - ", file.path(out_dir, "normal_chamber_genes_core_strict.tsv"))
  message(" - ", file.path(out_dir, "normal_chamber_programs.tsv"))
  message(" - ", file.path(out_dir, "bulk_chamber_DE_full.tsv"))
  message(" - ", file.path(out_dir, "bulk_chamber_stability.tsv"))
  message(" - ", file.path(out_dir, "bulk_chamber_core_genes.tsv"))
  message(" - ", file.path(out_dir, "bulk_chamber_fgsea.tsv"))
  message(" - ", file.path(out_dir, "NormalChamberPrior.tsv"))
  message(" - ", file.path(fig_dir, "figure1A_gse112339_pca_la_vs_ra.pdf"))
  message(" - ", file.path(fig_dir, "figure1B_gse112339_volcano_heatmap.pdf"))
}

main()
