﻿# Project README

## Project Principles

1. Statistical unit is **donor**, not **cell**.
2. Comparison is **paired LA vs RA** within donor, not pooled LA and RA.
3. This stage is a **baseline bulk analysis** of normal chamber difference, not a mechanistic or disease-level inference step.
4. Prioritize existing processed data and existing annotations; avoid unnecessary reprocessing.

## Tech Stack (Single Stack, All-R)

Use one unified R stack throughout the project:

- data.table
- edgeR
- limma
- fgsea
- zellkonverter
- SingleCellExperiment
- scuttle

## Windows Quick Start

If `Rscript` is not available in your terminal `PATH`, use the bundled PowerShell launcher:

```powershell
.\run_normal_chamber_analysis.ps1 `
  --count=GSE112339/GSE112339_HTSeq_hg19_Ensembl.txt.gz `
  --metadata=GSE112339/metadata.xlsx `
  --hallmark_gmt=path/to/hallmark.gmt `
  --reactome_gmt=path/to/reactome.gmt `
  --out_dir=.
```

The script now validates these required files at startup and stops immediately with a clear message if any are missing.

## Step 0: Define Final Deliverables

Before starting analysis, lock the completion criteria.

This stage is considered complete **only if the baseline bulk result files exist**:

1. `normal_chamber_genes_full.tsv`
- Content: full paired LA vs RA gene-level result table.

2. `normal_chamber_programs.tsv`
- Content: cleaned LA-biased / RA-biased baseline programs, NES, FDR, leading-edge genes, program class.

3. `normal_chamber_genes_core.tsv`
- Content: compact baseline chamber-associated gene prior for downstream comparison.

At this stage, `normal_chamber_attribution.tsv` is **not required** because single-cell evidence has not been integrated yet.

## Core Gene Prior Rule

`normal_chamber_genes_core.tsv` uses the recommended donor-stable filter:

- `stable_gene == TRUE`
- `FDR < 0.05`
- `abs(logFC) >= 0.5`

`normal_chamber_genes_core_strict.tsv` adds one more mechanism-oriented constraint:

- `is_core_gene == TRUE`

This keeps the full table and the baseline prior separate:

- `normal_chamber_genes.tsv` / `normal_chamber_genes_full.tsv`: full result table for traceability
- `normal_chamber_genes_core.tsv`: compact baseline chamber prior for downstream AF comparison
- `normal_chamber_genes_core_strict.tsv`: stricter program-anchored baseline prior for highlights and figures

## Interpretation Boundary

These outputs should be interpreted as a **baseline normal chamber reference** only.

- They support chamber-associated bulk differences in healthy tissue.
- They do **not** by themselves prove mechanism, cell-of-origin, or AF rewiring.
- Program labels and `program_class` are organizational summaries, not causal claims.
- Any disease interpretation must be made in a later comparative step against AF data.

## Step 1: Build Bulk-Level Normal Chamber Baseline from GSE112339

### 1.1 Read and Curate Metadata

Use only **LA** and **RA** samples from `GSE112339`.

Pass criteria:

- Final metadata must contain exactly **8 donors**.
- Every donor must have **both LA and RA** (strict pairing).
- Any donor missing one chamber must be excluded or metadata-fixed before continuing.

Hard stop rule:

- If strict 8-donor paired LA/RA is not achieved, **stop here**.
- Do not proceed to modeling or gene/program interpretation until metadata is corrected.

### 1.2 Keep Gene IDs Simple

For bulk statistical modeling:

- Keep original **Ensembl IDs** as primary gene identifiers.
- Do **not** convert all genes to symbols at the beginning.
- Do **not** deduplicate by symbol before differential modeling.

Rationale:

- Early symbol conversion can merge distinct Ensembl entries and distort effect estimates/FDR.
- ID mapping to symbols should be deferred to final reporting layers only.

### 1.3 Minimal QC

Run only 4 QC checks:

1. Total reads / library size per sample.
2. Number of detected genes per sample.
3. Sample-sample correlation heatmap.
4. PCA or MDS.

QC objective (not figure aesthetics):

- Determine whether any sample is an outlier.
- Determine whether LA and RA show an initial separation trend.

Batch-correction policy:

- Do **not** run batch correction by default.
- This dataset is from one series with one processing pipeline and paired-donor design.
- Unless PCA/MDS indicates a clear technical batch effect dominating chamber signal, do not apply ComBat or equivalent.

### 1.4 Low-Expression Filtering

Apply a simple filter before normalization:

- Keep genes with `CPM > 1` in at least `4` samples.

Reasoning:

- There are only 16 atrial samples in total.
- Remove near-unexpressed noise genes.
- Avoid overly strict filtering that may erase chamber-specific biology.

After this filter, proceed to normalization.

### 1.5 Normalization and Model

Recommended workflow:

- Use `edgeR::calcNormFactors()` for TMM normalization factors.
- Use `limma::voom()` for mean-variance modeling.
- Fit paired linear model with donor blocking in the design formula.

Core model:

```r
design <- model.matrix(~ donor + chamber, data = meta)
```

Testing target:

- Test the `chamber` term (LA vs RA) from this paired design.

First-principles rationale:

- The biological question is within-donor LA vs RA difference.
- Therefore donor must be included in the model.

Covariate policy for this stage:

- Do **not** add sex.
- Do **not** add age.
- Do **not** add many extra covariates.

Reason:

- This stage defines a healthy chamber-identity baseline, not population-level extrapolation.

### 1.6 Differential Analysis: Keep Full Ranking

Generate one complete differential table with at least:

- Ensembl ID
- gene symbol
- `logFC` (LA relative to RA)
- moderated `t`
- `P.Value`
- `FDR`
- average expression

Thresholding policy at this stage:

- Do **not** apply hard fold-change cutoffs at the beginning.
- Significance criterion: `FDR < 0.05`.
- Ranking criterion: order by moderated `t`.
- Reporting anchor genes: can additionally require `|logFC| > 0.5` in downstream reporting only.

### 1.7 Stability Check: Leave-One-Donor-Out

Run leave-one-donor-out (LODO) as a core robustness check.

Procedure:

- Run 8 iterations, each time removing 1 donor.
- Refit paired model `~ donor + chamber` on remaining donors.
- For each gene, record whether effect direction is consistent.
- For each pathway/program, record whether direction is consistent.

Stability definition:

- Stable gene: consistent direction in at least `7/8` runs.
- Stable program: consistent direction in at least `6/8` runs.

Priority rationale:

- At this stage, robust priors are more valuable than complex predictors.
- LODO stability is preferred over adding complex models (e.g., WGCNA, random forest, LASSO).

## Step 2: Define Normal Chamber Programs from Bulk Full Ranking

### 2.1 Use Only Two Gene-Set Families First

In the first round, use only:

- Hallmark
- Reactome

Do not use GO in this round.

Reason:

- GO is often highly redundant and may split one biological concept into many overlapping terms, which hurts interpretation.

### 2.2 Use Pre-Ranked FGSEA (No Initial GSVA)

Use the simplest pathway strategy aligned with paired bulk model:

- Rank genes by bulk moderated `t` from Step 1.
- Run `fgsea` in pre-ranked mode.

For each pathway, output at least:

- `NES`
- `padj`
- `leadingEdge`

Then classify pathways into:

- LA-biased programs
- RA-biased programs

### 2.3 Define Core Programs and Core Genes

For each significant pathway:

- Extract leading-edge genes.
- Intersect leading-edge genes with significant bulk genes.
- Keep the overlap as compact core genes for that pathway.

Reason:

- Program-grounded core genes are more interpretable than taking a simple top-N DEG list.

Final program set size:

- Keep only `3-5` major LA programs.
- Keep only `3-5` major RA programs.
- Prefer fewer programs if they already explain the biology.
